#=============================================================#
# QGuard API Client
# -----------------
# v1.0.0
#
# This script connects to a Qortex Server through sockets to
# the specified ports, receives data from each port, and
# combines all the data into one packet, which is then
# used by other python scripts.
#
#
# Data can be obtained through registering a callback function, 
# which is then called when the object list is updated. If
# there is no object listener, then the callback function will
# be called when the zone list is updated.
#
# Data can also be obtained through polling the "get_lists"
# function. "get_lists" will only return the combined lists,
# and will not provide any additional information about whether 
# or not the lists have been updated since the last poll. The
# data within the packet will have the timestamp in which the
# latest packet arrived from the server, if you wish to check
# if the packet is recent.
#
#=============================================================#

import lxml.etree as XmlTree
from collections import defaultdict
import traceback
import threading
import asyncore
import inspect
import socket
import struct
import json
import sys

import time
from datetime import datetime as dt

#=============================================================#
#
# [QGuard API Client - QGuardAPIClient]
#  Inherits from object
#
#  This class creates the listeners for each port if they are
#  valid QGuard API ports. It also stores the most recently
#  received object and zone lists for polling in addition
#  to sending them through the "on_update" callback
#
# [Inputs]
#  String - ip_address:
#   The ip address of the QGuard server
#
#  List - ports:
#   A list of integers, which are the ports to attempt
#    connection to
#   Only 17171 and 17172 are currently allowed
#    17171 is the object list port
#    17172 is the zone list port
#
# [Member Variables]
#  Object - listeners:
#   A dictionary that holds the different listeners connected
#    to the QGuard server
#
#  Object - object_list:
#   The dictionary representation of the incoming QGuard
#    server object list packet
#
#  Object - zone_list:
#   The dictionary representation of the incoming QGuard
#    server zone list packet
#
#  Object - server_connection_info:
#   A dictionary containing whether or not one of the listeners
#    is connected to the QGuard server. The timestamp within
#    the dictionary is updated with the timestamp of the
#    latest received packet from the server (independent of
#    the type of data received). For more fine-grained
#    synchronization analysis, each object in the object list
#    will have its own timestamp, assigned by the QGuard server
#    when it identifies a track.
#
#  Object - on_update_callback:
#   A bound function to call when the object list is updated
#   or, if there is no object listener, when the zone list is
#   updated
#
#=============================================================#

class QGuardAPIClient(object):
  def __init__(self, ip_addresses, need_objects):
    self.listeners = {"Object":{}, "Zone":{}}
    self.object_list = {}
    self.zone_list = {}
    self.server_connection_info = { "connected": False, "timestamp": 0 }
    self.on_update_callback = None
    self.object_list_port = 17171
    self.zone_list_port = 17172
    self.need_objects = need_objects

    for ip_address in ip_addresses:
      if self.need_objects:
        self.listeners["Object"][ip_address] = self.QGuardListener(ip_address, self.object_list_port)
        object_listener = self.listeners["Object"][ip_address]
        object_listener.on_data(self.update_objects, ip_address, self)
        object_listener.on_error(self.handle_error, self)
        object_listener.on_disconnect(self.reconnect_listeners, self)


      self.listeners["Zone"][ip_address] = self.QGuardListener(ip_address, self.zone_list_port)
      zone_listener = self.listeners["Zone"][ip_address]
      zone_listener.on_data(self.update_zones, ip_address, self)
      zone_listener.on_error(self.handle_error, self)
      zone_listener.on_disconnect(self.reconnect_listeners, self)
    
    asyncore.loop()

  #===========================================================#

  #===========================================================#
  #
  # [Attempt Connections - attempt_connections]
  #
  #  This method will attempt to connect each listener to the
  #  QGuard server
  #
  # [Inputs]
  #  None
  #
  # [Output]
  #  None
  #
  #===========================================================#

  def attempt_connections(self):
    for type, listener in self.listeners.iteritems():
      for ip, data in listener.iteritems():
        self.listeners[type][ip].attempt_connection()

  #===========================================================#

  #===========================================================#
  #
  # [Get Combined Lists - get_lists]
  #
  #  This method will return the combined object and zone
  #  list
  #
  # [Inputs]
  #  None
  #
  # [Output]
  #  Object:
  #   A dictionary with the structure:
  #   {
  #     "server_connection":
  #     {
  #       "connected": <Boolean>,
  #       "timestamp": <Integer>
  #     },
  #     "data": 
  #     {
  #       "Objects": <object_list>,
  #       "Zones": <zone_list>
  #     }
  #  }
  #
  #===========================================================#
  
  def get_lists(self):
    return self.combine_lists()

  #===========================================================#
 
  #===========================================================#
  #
  # [Register Update Callback - on_update]
  #
  #  This method registers a callback to call on list update
  #  You may pass in a bound function, a non-method function,
  #  or a method function with an object to bind it to
  #
  # [Inputs]
  #  Object - callback:
  #   The function to call
  #
  #  Object - obj:
  #   An object to bind the callback to. Defaults to None
  #
  # [Output]
  #  None
  #
  # [Modifies]
  #  member variable - on_update_callback
  #
  #===========================================================#

  def on_update(self, callback, obj=None):
    if obj:
      self.on_update_callback = callback.__get__(obj, obj.__class__)
    elif ((not inspect.ismethod(callback)) or
          (inspect.ismethod(callback) and callback.__self__)):
      self.on_update_callback = callback

  #===========================================================#
 
  #===========================================================#
  #
  # [Generate Combined Lists - combine_lists]
  #
  #  This method will combine object and zone lists, and
  #  server connection information into one dictionary
  #
  # [Inputs]
  #  None
  #
  # [Output]
  #  Object:
  #   The dictionary with combined lists and server information
  #
  #===========================================================#

  def combine_lists(self):
    local_time = dt.now()
    return ({
      "server_connection": self.server_connection_info,
      "data": {
        "Objects": self.object_list,
        "Zones": self.zone_list 
        },
      "server_ts": int(time.mktime(local_time.timetuple()))
      })
   
  #===========================================================#

  #===========================================================#
  #
  # [Update Object List - update_objects]
  #
  #  This method will update the stored object list with the
  #  latest list from the QGuard server
  #
  # [Inputs]
  #  Object - packet:
  #   The dictionary representation of the incoming packet
  #
  # [Output]
  #  None
  #
  # [Modified]
  #  member variable - server_connection_info
  #  member variable - object_list (through update_list)
  #
  #===========================================================#

  def update_objects(self, ipaddress, packet):
    self.server_connection_info = packet["server_connection"]

    object_list = packet["data"]
    self.update_list("object", ipaddress, object_list)
    if self.on_update_callback:
      self.on_update_callback(self.combine_lists())

  #===========================================================#

  #===========================================================#
  #
  # [Update Zone List - update_zones]
  #
  #  This method will update the stored zone list with the
  #  latest list from the QGuard server
  #
  # [Inputs]
  #  Object - packet:
  #   The dictionary representation of the incoming packet
  #
  # [Output]
  #  None
  #
  # [Modified]
  #  member variable - server_connection_info
  #  member variable - zone_list (through update_list)
  #
  #===========================================================#

  def update_zones(self, ipaddress, packet):
    self.server_connection_info = packet["server_connection"]

    zone_list = packet["data"]
    self.update_list("zone", ipaddress, zone_list)
    # Normally, downstream programs are updated when
    # the object list is updated. If there is no
    # object list connected, send data downstream here
    if self.need_objects:
      if "Object" not in self.listeners:
        self.on_update_callback(self.combine_lists())
    else:
      if self.on_update_callback:
        self.on_update_callback(self.combine_lists())

  #===========================================================#

  #===========================================================#
  #
  # [Update List - update_list]
  #
  #  This method will parse the incoming list data and update
  #  the stored list. Uses metaprogramming to select the list
  #  using the provided list type.
  #
  #  The method first attempts to parse the list data as
  #  if it were in json format. If it is unable to parse it
  #  as json, then it tries to parse the list data as xml.
  #  If the method is unable to parse the data as xml, then
  #  it discards the packet and sets the member list variable
  #  to an empty dictionary.
  #
  # [Inputs]
  #  String - list_type:
  #   The name of the list (ex. "object" for "object_list" and
  #                             "zone" for "zone_list"
  #
  #  Object - list_data:
  #   The data to parse
  #
  # [Output]
  #  None
  #
  # [Modified]
  #  member variable - <list_type>_list
  #
  #===========================================================#

  def update_list(self, list_type, ipaddress, list_data):
    if list_type == "object":
      try:
        self.object_list[ipaddress] =  json.loads(list_data)
      except ValueError:
        print("Error: could not translate object list packet into json, discarding packet")
        self.object_list[ipaddress] = {}
    elif list_type == "zone":
      try:
        self.zone_list[ipaddress] = json.loads(list_data)
      except ValueError:
        print("Error: could not translate Zone list packet into json, discarding packet")
        self.zone_list[ipaddress] = {}


  #===========================================================#
 
  #===========================================================#
  #
  # [Handle Error - handle_error]
  #
  #  This method is a callback passed to the listeners to be
  #  called when asyncore dispatcher throws an error. It
  #  reconnects listeners if their connections are refused.
  #  Resource Temporarily Unavailable [socket.error 11] is
  #  ignored since it is due to data not yet being available
  #  Any other exception will be handled with the default
  #  asyncore dispatcher error handler
  #
  # [Inputs]
  #  Object - listener:
  #   The listener object that threw the error
  #
  #  Object - exception_type:
  #   The type of exception thrown
  #
  #  Object - exception_value:
  #   The value of the exception thrown
  #
  #  Object - traceback:
  #   The traceback from the thrown exception
  #
  # [Output]
  #  None
  #
  #===========================================================#

  def handle_error(
        self,
        listener, 
        exception_type,
        exception_value,
        traceback):
    if exception_type == socket.error:
      if exception_value[0] == 111:
        # Attempt reconnection on [111] connection refused
        self.reconnect_listeners()
      elif exception_value[0] == 11:
        # Ignore [11] resource temporarily unavailable
        return 
    else:
      asyncore.dispatcher.handle_error(listener)
  
  #===========================================================#
 
  #===========================================================#
  #
  # [Reconnect Listeners - reconnect_listeners]
  #
  #  This method will attempt to reconnect each listener to the
  #  QGuard server after 1 second has passed
  #
  # [Inputs]
  #  None
  #
  # [Output]
  #  None
  #
  #===========================================================#
  def reconnect_listeners(self):
    print("")
    time.sleep(0.04)
    self.attempt_connections() 
  
  #===========================================================#

  #===========================================================#
  #
  # [QGuard Listener - QGuardListener]
  #  Inherits from asyncore.dispatcher
  #
  #  This class listens for packets from a specified QGuard
  #  server, then transmits that data to any registered
  #  receivers
  #
  #  This class is intended to be used internally by the 
  #  QGuardAPIClient, and as such, is only able to support
  #  one downstream recipient for received data.
  #
  #  Attempting to register an "on_data" callback twice will
  #  overwrite the callback stored in this class, removing
  #  the first callback registered.
  #
  #  If there is need to modify the class in the future to
  #  support multiple downstread data receivers, the class
  #  will have to be modified to have callback arrays instead
  #  of single callback functions, where newly registered
  #  callbacks will be stored in the array, and a mechanism
  #  for removing callbacks will have to be added.
  #
  # [Inputs]
  #  String - ip_address: 
  #   The ip_address to listen to
  #
  #  Integer - port: 
  #   The port to listen to
  #
  # [Members Variables]
  #  Tuple - host:
  #   A tuple with the ip address and port for the socket
  #
  #  Boolean - connected:
  #   Whether or not the listener is connected to the 
  #    server
  #  
  #  Integer - last_received_packet_timestamp:
  #   The timestamp of the last recevied packet, in seconds
  #
  #  Integer - packet_size:
  #   For reading packets from the server, the size of the
  #    next incoming packet
  #
  #  String - size_buffer:
  #   A string to store incoming size bytes
  #
  #  String - data_buffer:
  #   A string to store incoming data when we have the size
  #    of the incoming packet
  #
  #  Object - on_data_callback:
  #   A bound function that is called when a complete
  #    packet is read
  #
  #  Object - on_error_callback:
  #   A bound function that is called when handle_error is
  #    called by asyncore.dispatcher
  #
  # Object - on_disconnect_callback:
  #   A bound function that is called when handle_close
  #    is called by asyncore.dispatcher
  #
  #===========================================================#

  class QGuardListener(asyncore.dispatcher, object):
    def __init__(self, ip_address, port):
      # Initialize asyncore for asynchronous socket
      asyncore.dispatcher.__init__(self)

      # Connection information
      self.host = (ip_address, port)
      
      # Status information
      self.connected = False
      self.last_received_packet_timestamp = 0
      self.packet_size = None
      self.size_buffer = ""
      self.data_buffer = ""

      # Callbacks
      self.on_data_callback = None
      self.on_error_callback = None
      self.on_disconnect_callback = None
  
    #=========================================================#

    #=========================================================#
    #
    # [Register Data Callback - on_data]
    #
    #  This method registers a callback to call when a 
    #  complete packet is received
    #
    #  You may pass in a bound function, a non-method function,
    #  or a method function with an object to bind it to 
    #
    # [Inputs]
    #  Object - callback:
    #   The function to call
    #
    #  Object - obj:
    #   An object to bind the callback to. Defaults to None  
    #
    # [Output]
    #  None
    #
    # [Modifies]
    #  member variable - on_data_callback
    #   (through register_callback)
    #
    #=========================================================#

    def on_data(self, callback, ip_address, obj=None):
      self.register_callback("data", callback, obj, ip_address)

    #=========================================================#

    #=========================================================#
    #
    # [Register Error Callback - on_error]
    #
    #  This method registers a callback to call when an
    #  exception is thrown
    #
    #  You may pass in a bound function, a non-method function,
    #  or a method function with an object to bind it to 
    #
    # [Inputs]
    #  Object - callback:
    #   The function to call
    #
    #  Object - obj:
    #   An object to bind the callback to. Defaults to None  
    #
    # [Output]
    #  None
    #
    # [Modifies]
    #  member variable - on_error_callback
    #   (through register_callback)
    #
    #=========================================================#

    def on_error(self, callback, obj=None):
      self.register_callback("error", callback, obj)

    #=========================================================#

    #=========================================================#
    #
    # [Register Disconnect Callback - on_disconnect]
    #
    #  This method registers a callback to call when the
    #  socket is closed
    #
    #  You may pass in a bound function, a non-method function,
    #  or a method function with an object to bind it to 
    #
    # [Inputs]
    #  Object - callback:
    #   The function to call
    #
    #  Object - obj:
    #   An object to bind the callback to. Defaults to None  
    #
    # [Output]
    #  None
    #
    # [Modifies]
    #  member variable - on_disconnect_callback
    #   (through register_callback)
    #
    #=========================================================#

    def on_disconnect(self, callback, obj=None):
      self.register_callback("disconnect", callback, obj)

    #=========================================================#

    #=========================================================#
    #
    # [Register Callback - register_callback]
    #
    #  This method registers a callback to call. Uses
    #  metaprogramming to select the callback variable
    #  using the provided callback type.
    #
    #  You may pass in a bound function, a non-method function,
    #  or a method function with an object to bind it to 
    #
    # [Inputs]
    #  String - callback_type:
    #   The name of the callback 
    #    ex. "data" for "on_data_callback"
    #        "error" for "on_error_callback"
    #
    #  Object - callback:
    #   The function to call
    #
    #  Object - obj:
    #   An object to bind the callback to. Defaults to None  
    #
    # [Output]
    #  None
    #
    # [Modifies]
    #  member variable - on_<callback_type>_callback
    #
    #=========================================================#

    def register_callback(self, callback_type, callback, obj=None, ip_address=None):
      callback_name = "on_" + callback_type + "_callback"
      bound_callback = None
      if obj:
        bound_callback = callback.__get__(obj, obj.__class__)
      elif ((not inspect.ismethod(callback)) or
            (inspect.ismethod(callback) and callback.__self__)):
        bound_callback = callback

      self.__setattr__(callback_name, bound_callback)

    #=========================================================#

    #=========================================================#
    # 
    # [Attempt Connection - attempt_connection]
    #
    #  This method attemps to connect to the server, closing
    #  the socket if it already exists in case this method
    #  is called as an attempt to reconnect to a server after
    #  being disconnected by the other party
    #  
    # [Inputs]
    #  None
    #
    # [Output]
    #  None
    #
    #=========================================================#

    def attempt_connection(self):
      if not self.connected:
        print("Attempting connection to " + 
              self.host[0] + 
              " on port " + 
              str(self.host[1]))
        if self.socket:
          self.close()
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect(self.host)
   
    #=========================================================#

    #=========================================================#
    #
    # [Handle Connect - handle_connect]
    #
    # This method is a callback in the asyncore interface.
    # It is called on a successful connect, and sets the
    # member connected boolean
    #
    # [Inputs]
    #  None
    #
    # [Output]
    #  None
    #
    # [Modifies]
    #  member variable - downstream_sockets
    #
    #=========================================================#
    
    def handle_connect(self):
      print("Connected to server at " +
            self.host[0] +
            " on port " +
            str(self.host[1]))
      self.connected = True

    #=========================================================#

    #=========================================================#
    #
    # [Handle Error - handle_error]
    #
    # This method is a callback in the asyncore interface.
    # It passes the exception information to the error
    # callback if that callback exists. Otherwise, it uses
    # the default asyncore.dispatcher error behavior
    #
    # [Inputs]
    #  None
    #
    # [Output]
    #  None
    #
    #=========================================================#

    def handle_error(self):
      exception_type, exception_value, traceback = sys.exc_info()
      if (exception_type == socket.error and
          exception_value[0] == 111):
        print("Connection refused")
     
      if self.on_error_callback: 
        self.on_error_callback(
          self,
          exception_type,
          exception_value,
          traceback)
      else:
        asyncore.dispatcher.handle_error(self)

    #=========================================================#

    #=========================================================#
    #
    # [Handle Close - handle_close]
    #
    # This method is a callback in the asyncore interface.
    # It calls the disconnect callback if it exists and sets
    # the member connected boolean to false.
    #
    # [Inputs]
    #  None
    #
    # [Output]
    #  None
    #
    # [Modified]
    #  member variable - connected
    #  member variable - (internal socket)
    #
    #=========================================================#

    def handle_close(self):
      self.close()
      print("Connection to server at " +
            self.host[0] + 
            " on port " +
            str(self.host[1]) +
            " lost")
      self.connected = False
      self.on_disconnect_callback()

    #=========================================================#

    #=========================================================#
    #
    # [Handle Read - handle_read]
    #
    # This method is a callback in the asyncore interface.
    # It continues reading bytes until a complete packet is
    # read. Once a complete packet is read, the packet is sent
    # downstream through the on_data_callback
    #
    # [Inputs]
    #  None
    #
    # [Output]
    #  None
    #
    # [Modified]
    #  member_variable - packet_size
    #  member_variable - size_buffer
    #  member variable - data_buffer
    #  member variable - last_received_packet_timestamp
    #  member variable - last_received_message
    #
    #=========================================================#

    def handle_read(self):
      if self.packet_size is None:
        remaining_size_bytes = 4 - len(self.size_buffer)
        if (remaining_size_bytes > 0):
          self.size_buffer += self.recv(remaining_size_bytes)
        else:
          if struct.unpack("<L", self.size_buffer)[0] > sys.maxint:
            self.packet_size = sys.maxint/10000
          else:
            self.packet_size = struct.unpack("<L", self.size_buffer)[0]
          self.size_buffer = ""
      else:
        try:
            remaining_data_bytes = (self.packet_size - len(self.data_buffer))
            if remaining_data_bytes >= sys.maxint:
              remaining_data_bytes = sys.maxint/10000
            self.data_buffer += self.recv(remaining_data_bytes)
        except Exception as e:
            print "Handle Read error:", str(e)
            print "remaining_data_bytes: ", remaining_data_bytes
            print "packet_size: ", self.packet_size
            print "data_buffer: ", len(self.data_buffer)
        if len(self.data_buffer) == self.packet_size:
          self.last_received_packet_timestamp = int(time.time())
          self.last_received_message = self.data_buffer

          if self.on_data_callback:
            self.on_data_callback(
              self.host[0],
              {"server_connection": {
                "connected": self.connected,
                "timestamp": self.last_received_packet_timestamp },
              "data": self.data_buffer })
          
        self.data_buffer = ""
        self.packet_size = None
    
    #=========================================================#
#=============================================================#
   
#=============================================================#
# Utility Functions
#=============================================================#

#=============================================================#
# 
# [Convert Parsed QGuard XML Element Tree to Python Dictionary -
#  etree_to_dict]
#
#  This function takes the parsed QGuard XML packet in the
#  form of an element tree and converts it into a python
#  dictionary for easy modification
#
#  The function will recursively call on subtrees to generate
#  nested dictionaries or arrays
#
# [Inputs]
#  Object - tree:
#   The tree or subtree to translate into a dictionary
#
# [Final Output]
#  Object:
#   A dictionary with the same internal structure as the
#   XML. Repeated tags are stored in arrays and tags with
#   no children are key-value pairs in the dictionary
#
#=============================================================#

def etree_to_dict(tree):
  result = None
  node = None
  if (type(node) is XmlTree.ElementTree):
    node = tree.getroot()
  else:
    node = tree

  # Item is a special case because the tag only exists
  # in xml, and is not part of the memory object, so the
  # "item" tag should not show up in the resulting
  # dictionary
  if node.tag == "item":
    result = {}
    for child in node:
      result[child.tag] = etree_to_dict(child)

    return result
  # Object is a special case because the tag only exists
  # in xml. In a memory, it is an array, so we want it
  # to be an array even if it is empty or if it only
  # has one child
  elif node.tag == "object":
    result = []
    for child in node:
      result.append(etree_to_dict(child))

    return result

  #=========================#

  child_tags = list(set([item.tag for item in list(node)]))

  # There are no children, base case
  if len(child_tags) == 0:
    if node.tag == "sequence":
      return int(node.text)
    elif (node.tag == "x" or
          node.tag == "y" or
          node.tag == "z"):
      return float(node.text)
    else:
      return node.text
  # Only one type of child, we are either a node or an array
  elif len(child_tags) == 1:
    children = node.findall(child_tags[0])
    # Only one child, add it to the object
    if len(children) == 1:
      result = {}
      result[child_tags[0]] = etree_to_dict(children[0])
    # More than one child, we are an array
    else:
      result = []
      for child in children:
        result.append(etree_to_dict(child))
  # There are children, continue
  else:
    result = {}
    for tag in child_tags:
      children = node.findall(tag)
      for child in children:
        result[tag] = etree_to_dict(child)

  return result

#=============================================================#

#=============================================================#
#
# [Add Element To Element Tree - add_element_to_etree]
#
#  This function is used in dict_to_etree. It adds a child
#  element to the tree, with specific rules added to create
#  the "object", "zones", and "item" tags.
#
#  If an array is passed in without a tag, it is assumed that
#  it is the root of the element tree and will create a tag
#  called "items"
#
# [Inputs]
#  String - tag:
#   The tag to give the XML Element
#
#  Object - data:
#   Can be any type, as long as it is a list, dict, or can
#   be turned into a string
#
#  Object - parent:
#   The parent node to attach the resulting node to
#
# [Output]
#  None
#
# [Modified]
#  paramter variable - parent
#
#=============================================================#

def add_element_to_etree(tag, data, parent):
  if type(data) is list:
    node = None
    if tag == "object":
      node = XmlTree.SubElement(parent, "object")
    elif tag == "zones":
      node = XmlTree.SubElement(parent, "zones")
    else:
      node = XmlTree.SubElement(parent, "items")
      
    for item in data:
      item_node = XmlTree.SubElement(node, "item")
      if type(item) is dict:
        keys = item.keys()
        keys.sort()
        for key in keys:
          add_element_to_etree(key, item[key], item_node)
      else:
        item_node.text = str(item)
  elif type(data) is not dict:
    node = XmlTree.SubElement(parent, tag)
    node.text = str(data)
  else:
    node = XmlTree.SubElement(parent, tag)
    keys = data.keys()
    keys.sort()
    for key in keys:
      add_element_to_etree(key, data[key], node)

#=============================================================#

#=============================================================#
#
# [Convert Python Dictionary to Element Tree - dict_to_etree]
#
#  This function takes a python dictionary and recursively
#  generates an element tree using add_element_to_etree
#
# [Inputs]
#  Object - node:
#   The input dictionary
#
# [Output]
#  Object:
#   The ElementTree built from the dictionary
#
#=============================================================#

def dict_to_etree(node):
  root = None
  if type(node) is list:
    root = XmlTree.Element("items")
    # Add all items
    for item in node:
      item_node = XmlTree.SubElement(root, "item")
      keys = item.keys()
      keys.sort()
      for key in keys:
        add_element_to_etree(key, item[key], item_node) 
  else:
    root = XmlTree.Element("item")
    keys = node.keys()
    keys.sort()
    for key in keys:
      add_element_to_etree(key, node[key], root) 

  return XmlTree.ElementTree(root)

#=============================================================#

