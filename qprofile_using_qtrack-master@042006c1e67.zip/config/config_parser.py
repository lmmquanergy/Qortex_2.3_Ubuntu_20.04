import yaml
import os


class ConfigParser:

    def __init__(self):
        self.__config_file_name = 'config.yaml'
        self.__configs = {}
        current_dir = os.path.dirname(os.path.realpath(__file__))
        config_file_path = os.path.join(current_dir, self.__config_file_name)

        with open(config_file_path, 'r') as f:
            self.__configs = yaml.load(f, Loader=yaml.Loader)
        f.close()


    def get_configs(self):
        return self.__configs


    def check_config_key(self, key):
        if not key in self.__configs:
            print "Missing configuration {0}".format(key)
            return False
        return True
