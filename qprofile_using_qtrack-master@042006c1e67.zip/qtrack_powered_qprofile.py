#!/usr/bin/env python

#=======================================================#
# QGuard Object List Geolocation Translator
# -----------------------------------------
# v1.1.2
#
# changelog:
#
# v1.1.2
#
# Change geo_info - self.broadcaster = self.ListBroadcaster(
# from  "localhost",
# to    "0.0.0.0",
#
# This allows connection to the output port from other machines
# not just the localhost.
#
# v1.1.1
# Add translations for velocity from an x, y, z vector
# to track and speed. We keep x, y, z in the packet
# to retain backwards compatability.
#
# v1.0.1
# Fixed a bug where "send_packet"size" wasn't being
# checked before sending the packet size. It now checks
# and won't send the packet size if it is not requested
#
#=======================================================#
# 
# This script will read the object list and zone list
# from QGuard and will use the location of the QGuard
# server's primary sensor to determine the latitude and
# longitude of the objects in the object list.
#
# QGuard server's primary sensor location is provided
# through a configuration files located in the "config"
# folder.
#
# IP address and port information is also provided to
# the script through the configuration file.
#
# The script currently only supports one QGuard server
# and must be modified if multiple server support is
# required (i.e. combining object lists from several
# different servers or locations).
#
# The output of this script is broadcast through sockets
# in either xml or json as specified in the configuration
# file. The port number to broadcast on is also provided
# through the configuration file.
#
# There is the option to turn off the sending of packet
# sizes before the packet itself is the user of this
# script wishes to use a parser instead of byte count
# to determine if a complete packet has been received
#
# The format of the output is the same as the output
# provided by QGuard with a few minor alterations:
#   The position structure as a "lat" and "long" key
#   in addition to the "x", "y", and "z" keys
#   There is an list called "zones" added to each
#   object, which will contain all of the zones that
#   the object within
#
# There will not be an example output packet listed
# here because of the dependance on QGuard's object
# list and zone list formats. If QGuard's data API
# changes, then the output of this script will also
# change
#   
#=======================================================#

import quanergy.qtrack_api_client as quanergy
import lxml.etree as XmlTree
import asyncore
import socket
import struct
import json
import sys
import copy
from config.config_parser import ConfigParser
import time
from datetime import datetime as dt
from collections import defaultdict


cp = ConfigParser()
configs = cp.get_configs()
#DEFAULT_CONFIG_FILEPATH = "/opt/quanergy/qguard_geolocation_translator/config/config.ini"

DEFAULT_CONFIG_FILEPATH = "config/config.ini"

running_heartbeat = defaultdict(lambda: defaultdict(lambda: None))
combined_object_list = defaultdict(lambda: defaultdict(lambda: None))

# The following dict keeps an object details which is currently visible in the object list
# This will have details like: first and last seen ts_epoch, locations, sequences, and first and last picture details
current_object_details = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: None)))
actual_object_details = defaultdict(lambda: defaultdict(lambda: None))

# The following dict keeps a track of all the objects in the zones
# Key is the zone id and next key is the object id
# It contains details like fist and last seen ts_epoch and sequence
current_objects_in_zones = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: None)))

# The following dict keeps a track of entry, exit, disappearance and appearance
# of all the objects in the zones
current_objects_zones_status = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: None)))
current_objects_appear_status = defaultdict(lambda: defaultdict(lambda: None))


# Main dictionary keeping a track of currently stitched objects
handover_list_external = defaultdict(lambda: "0")
# This is just the reverse of the stitch list.
handover_list_rev = defaultdict(lambda: defaultdict(lambda: None))

# Keep a track of most lagging server timestamp
least_ts = defaultdict(lambda: None)
max_ts = defaultdict(lambda: None)
last_handover_ts = 0
last_cleanup_ts = 0
last_broadcast_ts = 0

# This is an implementation of default dict where the value is the key if key is not present
class MyDict(dict):
    __missing__ = lambda self, key: key

# We want this to return the same value as we are looking for unless it's been assigned to a different id
# We enter the key as the newly appeared id and the value as the disappeared object id
handover_list = MyDict()

# Testing list
testing = []

#Last health check minute
last_health_min = 0

sequence = 0
combined_zones = defaultdict(lambda: defaultdict(lambda: None))
new_objects = defaultdict(lambda: defaultdict(lambda: None))

#servers = {}

#=======================================================#
#
# [QGuard Geolocation Translator - 
#   QGuardGeolocationTranslator]
#  Inherits from object
#
#  This class loads the configuration files, prepares 
#  the listener, broadcaster, then starts listening
#  to QGuard output. 
#
# [Inputs]
#  String - config_filepath:
#   The filepath to the configuration file.
#   Defaults to "config/config.ini"
#
# [Member Variables]
#  Object - listener:
#   A QGuardAPIClient instance
#
#  Object - broadcaster:
#   A ListBroadcaster instance
#
#=======================================================#


class QtracktoQprofileTranslator(object):
    def __init__(self, conf=configs):
        self.listener = quanergy.QGuardAPIClient(conf["qortex"]["server_list"].keys(), bool(conf.get("need_objects", 0)))

        self.broadcaster = self.ListBroadcaster(
          "0.0.0.0",
          int(conf["broadcaster"]["port"]),
          bool(conf["broadcaster"]["send_packet_size"]),
          conf["qortex"]["server_list"],
          int(conf["broadcaster"]["heartbeat_frequency"]))

        self.listener.on_update(self.broadcaster.update_list, self.broadcaster)
        self.listener.attempt_connections()

        asyncore.loop()



    #========================================================#
    #========================================================#
    #
    # [List Broadcaster - ListBroadcaster]
    #  Inherits from asyncore.dispatcher
    #
    #  This class receives a QGuard API Client packet and then
    #  broadcasts the packet to all of its downstream clients
    #  after adding geographical coordinates and zone
    #  information to each object in the object list
    #
    # [Inputs]
    #  String - ip_address:
    #   The ip_address to broadcast on
    #
    #  Integer - port:
    #   The port to broadcast on
    #
    #  String - message_format:
    #   The format in which to broadcast
    #
    #  Boolean - send_packet_size:
    #   Whether or not to send the packet size before the
    #    packet itself
    #
    #  Object - location:
    #   A dictionary containing the latitude and longitude of
    #    the primary sensor of the QGuard server sending the
    #    object list
    #
    # [Members Variables]
    #  Float - lat:
    #   The latitude of the primary sensor
    #
    #  Float - long:
    #   The longitude of the primary sensor
    #
    #  Integer - heading:
    #   The direction that the "front" of the primary sensor
    #    is facing (degrees from north)
    #
    #  Boolean - send_packet_size:
    #   Whether or not to send the size of a packet before
    #    the packet itself
    #
    #  String - message_format:
    #   The format in which to broadcast
    #
    #  Set - downstream_sockets:
    #   A set of downstream sockets to broadcast to
    #
    #========================================================#
    class ListBroadcaster(asyncore.dispatcher):
        def __init__(
                  self,
                  ip_address,
                  port,
                  send_packet_size,
                  in_out_zones,
                  heartbeat_frequency):
            asyncore.dispatcher.__init__(self)
            self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
            self.set_reuse_addr()
            self.bind((ip_address, port))
            self.listen(5)
            self.message_format = "json"
            self.send_packet_size = send_packet_size
            if heartbeat_frequency == 0:
                self.send_heartbeat = 0
                self.broadcast_interval = 1
            else:
                self.send_heartbeat = 1
                self.broadcast_interval = int(1000/heartbeat_frequency)
            self.downstream_sockets = set()
            self.zone_details = defaultdict(lambda: defaultdict(lambda: None))
            self.reverse = {"one": "two", "two": "one"}
            for server, doors in in_out_zones.iteritems():
                for door, zones in doors.iteritems():
                    self.zone_details[''.join([server, "-", zones["first_beam"]])]["type"] = "one"
                    self.zone_details[''.join([server, "-", zones["first_beam"]])]["door"] = door
                    self.zone_details[''.join([server, "-", zones["second_beam"]])]["type"] = "two"
                    self.zone_details[''.join([server, "-", zones["second_beam"]])]["door"] = door
            print json.dumps(self.zone_details)
        #======================================================#
        #======================================================#
        #
        # [Handle Accept - handle_accept]
        #
        #  This method is a callback in the asyncore interface.
        #  It stores downstream connections for broadcasting
        #
        # [Inputs]
        #  None
        #
        # [Output]
        #  None
        #
        # [Modifies]
        #  member variable - downstream_sockets
        #  member variable - (internal socket)
        #
        #======================================================#
        def handle_accept(self):
          client_info = self.accept()
          if client_info is not None:
            sock, address = client_info
            self.downstream_sockets.add((sock, address))
            print("Connected with client at " +
                  address[0] +
                  " on port " +
                  str(address[1]))
            print("There are now " +
                  str(len(self.downstream_sockets)) +
                  " connections")
        #======================================================#
        #======================================================#
        #
        # [Handle Close - handle_close]
        #
        # This method is a callback in the asyncore interface
        # It closes the internal socket and clears downstream
        # sockets
        #
        # [Inputs]
        #  None
        #
        # [Output]
        #  None
        #
        # [Modifies]
        #  member variable - downstream_sockets
        #  member variable - (internal socket)
        #
        #======================================================#
        def handle_close(self):
          self.close()
          self.downstream_sockets = set()
        #======================================================#
        #======================================================#
        #
        # [Update List - update_list]
        #
        #  This method adds geographical coordinates and zones
        #  to the object list in the incoming list data before
        #  broadcasting the modified list downstream
        #
        # [Inputs]
        #  Object - message:
        #    The dictionary sent from the QGuardAPIClient class.
        #    It contains the object information, zone information,
        #     and information about the status of the connection
        #     to the QGuard server
        #
        # [Output]
        #  None
        #
        #======================================================#
        def update_list(self, message):
            list_data = message["data"]
            list_time = message["server_ts"]
            self.count_people(list_data["Zones"], list_data["Objects"], list_time)

        #======================================================#
        #======================================================#
        #
        # [Broadcast - broadcast]
        #
        #  This method sends modified incoming list data to all
        #  connected client sockets. It will convert the python
        #  dictionary into either json or xml as specified by
        #  the configuration file and then send the resulting
        #  string through connected sockets. If a send attempt
        #  fails, the socket will be considered disconnected
        #  and removed from the set of downstread sockets
        #
        # [Inputs]
        #  Object - list_data:
        #    The modifed dictionary sent from the QGuardAPIClient
        #     class.
        #    It contains the object information (with
        #     added geographic coordinates and zones), zone
        #     information, and information about the status of
        #     the connection to the QGuard server
        #
        # [Output]
        #  None
        #
        # [Modifies]
        #  member variable - downstream_sockets
        #
        #======================================================#
        def broadcast(self, list_data):
            expired_sockets = set()
            # Convert into either json or xml, defined in the config file
            if self.message_format == "json":
              for sock, info in self.downstream_sockets:
                try:
                  #json_message = json.dumps(list_data, indent=2)
                  json_message = json.dumps(list_data)
                  json_message = ''.join([json_message, '\n'])
                  if self.send_packet_size:
                    #print len(json_message)
                    sock.send(struct.pack("<L", len(json_message)))
                  sock.send(json_message)
                except socket.error as e:
                  print("Disconnected from client at " +
                        info[0] +
                        " on port " +
                        str(info[1]) + str(e))
                  expired_sockets.add((sock, info))
            elif self.message_format == "xml":
              xml_tree = quanergy.dict_to_etree(list_data)
              xml_string = XmlTree.tostring(
                xml_tree.getroot(),
                pretty_print="True")
              for sock, info in self.downstream_sockets:
                try:
                  if self.send_packet_size:
                    sock.send(struct.pack("<L", len(xml_string)))
                  sock.send(xml_string)
                except socket.error as e:
                  print("Disconnected from client at " +
                        info[0] +
                        " on port " +
                        str(info[1]))
                  expired_sockets.add((sock, info))
            if (len(expired_sockets) > 0):
              self.downstream_sockets -= expired_sockets
              print("There are now " +
                    str(len(self.downstream_sockets)) +
                    " connections")


        def count_people(self, zone_list, object_list, list_time):
            global sequence
            global last_cleanup_ts
            global running_heartbeat
            global last_broadcast_ts
            global combined_object_list
            current_header_ts = list_time
            # This will go away once we start using object list data. For now this is just a warning
            if object_list:
                print "Object list data received but not used."

            for server, zone_data in zone_list.iteritems():
                if not zone_data:
                    continue

                try:
                    running_heartbeat[server]["timestamp"] = int(zone_data["header"]["timestamp"])
                    current_header_ts = int(zone_data["header"]["timestamp"])
                except Exception as e:
                    print("Failed to read timestamp in zone list with error: {0}".format(e))
                    continue

                running_heartbeat[server]["ip"] = server
                running_heartbeat[server]["status"] = []

                if "zones" in zone_data:
                    for zone in zone_data["zones"]:
                        if "objectIds" not in zone:
                            print("Malformed zone list: no objectIds array. Skipping.")
                            continue
                        zid = ''.join([server, "-", zone["name"]])
                        if zid in self.zone_details:
                            ztype = self.zone_details[zid]["type"]
                            zdoor = self.zone_details[zid]["door"]
                            for o in zone["objectIds"]:
                                oid = ''.join([server, "-", o])
                                current_object_details[oid]["last_ts_epoch"] = current_header_ts
                                if not current_object_details[oid][self.reverse[ztype]]:
                                    if not current_object_details[oid][ztype]:
                                        current_object_details[oid][ztype]["name"] = zid
                                        current_object_details[oid][ztype]["ts"] = current_header_ts
                                    else:
                                        if zid != current_object_details[oid][ztype]["name"]:
                                            current_object_details[oid][ztype]["name"] = zid
                                            current_object_details[oid][ztype]["ts"] = current_header_ts
                                else:
                                    if not current_object_details[oid][ztype]:
                                        current_object_details[oid][ztype]["name"] = zid
                                        current_object_details[oid][ztype]["ts"] = current_header_ts
                                        if zdoor != self.zone_details[current_object_details[oid][self.reverse[ztype]]["name"]]["door"]:
                                            current_object_details[oid][self.reverse[ztype]] = defaultdict(lambda: defaultdict(lambda: None))
            cleanup = []

            for obj, details in current_object_details.iteritems():
                new_obj = defaultdict(lambda: None)
                if details["one"] and details["two"]:
                    new_obj["id"] = obj
                    new_obj["position"] = 0.0
                    new_obj["speed"] = 1.5
                    new_obj["objectClass"] = "HUMAN"
                    if details["one"]["ts"] > details["two"]["ts"]:
                        new_obj["timestamp"] = details["two"]["ts"]
                        new_obj["direction"] = "BACKWARD"
                        new_obj["duration"] = details["one"]["ts"] - details["two"]["ts"]
                    elif details["one"]["ts"] < details["two"]["ts"]:
                        new_obj["timestamp"] = details["one"]["ts"]
                        new_obj["direction"] = "FORWARD"
                        new_obj["duration"] = details["two"]["ts"] - details["one"]["ts"]
                    else:
                        cleanup.append(obj)
                    if new_obj["direction"]:
                        #print json.dumps(new_obj)
                        #print json.dumps(current_object_details)
                        combined_object_list[obj]["object"] = new_obj
                        combined_object_list[obj]["header_ts"] = current_header_ts

            for obj in combined_object_list:
                cleanup.append(obj)

            current_ts = int(time.time()*1000)

            if current_ts > last_cleanup_ts + 5000:
                #print json.dumps(current_object_details)
                for obj, details in current_object_details.iteritems():
                    if details["last_ts_epoch"]< current_header_ts + 10000:
                            cleanup.append(obj)

            for obj in cleanup:
                current_object_details.pop(obj, None)
            last_cleanup_ts = current_ts

            #print json.dumps(current_object_details)

            if len(combined_object_list) > 0:
                sequence += 1
                l = []
                t = []
                for o in combined_object_list.values():
                    l.append(o["object"])
                    t.append(o["header_ts"])
                new_ol = {"header": {"messageType": "DETECTION","numObjects": str(len(combined_object_list)),"sequence": str(sequence),"timestamp": current_header_ts,"version": "1.0" }, "object": l}
                self.broadcast(new_ol)
                combined_object_list = defaultdict(lambda: defaultdict(lambda: None))
                last_broadcast_ts = current_ts

            if self.send_heartbeat:
                if current_ts >= last_broadcast_ts + self.broadcast_interval:
                    last_broadcast_ts = current_ts
                    sequence += 1
                    new_hb = {"header": {"messageType": "HEARTBEAT","sequence": str(sequence),"timestamp": current_ts,"version": "1.0.0" },"status": running_heartbeat.values() }
                    self.broadcast(new_hb)
                    last_broadcast_ts = current_ts

            return

#==========================================================#

import math

#==========================================================#
#
# [Convert to Radians - deg_to_rad]
#
#  This function converts incoming degrees to radians
#
# [Inputs]
#  Number - deg:
#   The value to be converted
#
# [Output]
#  Float:
#   The incoming value in degrees converted to radians
#
#==========================================================#

def deg_to_rad(deg):
  return (float(deg) * (math.pi / 180.0))

#==========================================================#
#
# [Convert to Degrees - rad_to_deg]
#
#  This function converts incoming radians to degrees
#
# [Inputs]
#  Number - rad:
#   The value to be converted
#
# [Output]
#  Float:
#   The incoming value in degrees converted to degrees
#
#==========================================================#

def rad_to_deg(rad):
  return (float(rad) * (180.0 / math.pi))

#==========================================================#
#
# [Cartesian to Geographic Coordinates - xyz_pos_to_geo]
#
#  This function converts incoming cartesian coordinates
#  and a reference point to global geographic coordinates
#  in latitude and longitude. Latitude and longitude are
#  in degrees.
#
# [Inputs]
#  Float - origin_lat:
#   The latitude of the reference point
#
#  Float - origin_long:
#   The longitude of the reference point
#
#  Float - origin_bearing:
#   The direction that the reference point is facing
#
#  Float - x:
#   The x coordinate of the object in relation to the
#    reference point
#
#  Float - y:
#   The y coordinate of the object in relation to the
#    reference point
#
#  Float - z:
#   The z coordinate of the object in relation to the
#    reference point. This coordinate represents
#    height of the object
#
# [Output]
#  Object:
#   A structure with the format:
#   {
#    "lat": Float,
#    "long": Float
#   }
#
#==========================================================#

def xyz_pos_to_geo(
        origin_lat,
        origin_long,
        origin_bearing,
        x,
        y,
        z):
  distance = math.sqrt(x*x + y*y + z*z)
  earth_radius = 6371000.0
  angular_distance = distance / earth_radius
  bearing_offset = deg_to_rad(origin_bearing)
  lat1 = deg_to_rad(origin_lat)
  long1 = deg_to_rad(origin_long)
  bearing = bearing_offset + math.atan2(y, x)

  lat2 = math.asin((math.sin(lat1) *
                    math.cos(angular_distance)) +
                   (math.cos(lat1) *
                    math.sin(angular_distance) *
                    math.cos(bearing)))

  long2_y = (math.sin(bearing) *
             math.sin(angular_distance) *
             math.cos(lat1))
  long2_x = (math.cos(angular_distance) -
             (math.sin(lat1) *
              math.sin(lat2)))
  long2 = (long1 +
           math.atan2(long2_y, long2_x))
  lat2 = rad_to_deg(lat2)
  long2 = rad_to_deg(long2)

  return { "lat": lat2, "long": long2 }

#==========================================================#
#
# [xyz_vel_to_geo]
#
#  This function converts incoming cartesian velocity
#  vector and a reference point to heading (relative to
#  the object) and speed. Heading (labelled as track) is
#  in degrees.
#
# [Inputs]
#  Float - origin_bearing:
#   The direction that the reference point is facing
#
#  Float - x:
#   The x component of the object's velocity 
#    in relation to the reference point
#
#  Float - y:
#   The y component of the object's velocity 
#    in relation to the reference point
#
#  Float - z:
#   The y component of the object's velocity 
#    in relation to the reference point. This 
#    coordinate represents height of the object
#
# [Output]
#  Object:
#   A structure with the format:
#   {
#    "track": Float,
#    "speed": Float
#   }
#
#==========================================================#

def xyz_vel_to_geo(
        origin_bearing,
        x,
        y,
        z):
  speed = math.sqrt(x*x + y*y + z*z)
  bearing_offset = deg_to_rad(origin_bearing)
  track = bearing_offset + math.atan2(y, x)
  track = rad_to_deg(track)

  return { "track": track, "speed": speed }

#==========================================================#
#
# [Parse Arguments - parse_args]
#
#  This function parses command line arguments using
#  argparse
#
#==========================================================#
def parse_args():
  import argparse

  args_parser = argparse.ArgumentParser()

  args_parser.add_argument(
    "--config-filepath",
    default=DEFAULT_CONFIG_FILEPATH,
    help="Location of the configuration file")

  return args_parser.parse_args()

#==========================================================#
#
# [Main - main]
#  The entry point to the program
#
# [Inputs]
#  Object - args:
#   The result of running argparse.ArgumentParser.parse_args
#
#==========================================================#

def main(args):
  QtracktoQprofileTranslator()

#==========================================================#

if __name__ == "__main__":
  try:
    args = parse_args()
    main(args)
  except KeyboardInterrupt:
    sys.exit(1)

